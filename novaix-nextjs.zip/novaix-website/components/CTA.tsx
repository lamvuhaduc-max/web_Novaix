import Reveal from "./Reveal";

export default function CTA() {
  return (
    <section id="lien-he" className="py-[110px] relative z-[2]">
      <div className="wrap">
        <Reveal>
          <div className="border border-line rounded-[26px] py-16 px-10 text-center relative overflow-hidden"
            style={{ background: "radial-gradient(60% 120% at 50% 0%,rgba(45,212,191,0.14),transparent 70%),#0b1120" }}>
            <span className="kicker">Bắt đầu ngay hôm nay</span>
            <h2 className="font-extrabold mt-[18px] mb-4" style={{ fontSize: "clamp(30px,4.5vw,54px)" }}>
              Sẵn sàng hệ thống hóa<br />doanh nghiệp của bạn?
            </h2>
            <p className="text-muted max-w-[520px] mx-auto mb-7">
              Đặt lịch demo 30 phút — chúng tôi sẽ phân tích quy trình hiện tại và đề xuất lộ trình
              số hóa phù hợp, hoàn toàn miễn phí.
            </p>
            <div className="flex gap-3.5 justify-center flex-wrap">
              <a href="mailto:contact@novaix.vn" className="btn btn-primary">Đặt lịch demo →</a>
              <a href="tel:+84" className="btn btn-ghost">Gọi tư vấn</a>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
